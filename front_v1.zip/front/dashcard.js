
function exibirdash() {

    //window.alert(localStorage.getItem("id_agente"))
    fetch("http://localhost:8080/Transactions/countAceito/" + localStorage.getItem("id_agente"))
        .then(res => res.json())
        .then(res => {
            document.getElementById("Sucesso").innerHTML = "<br><h3>Aceito: " + res + "</h3>";
        })

    fetch("http://localhost:8080/Transactions/countRejeitado/" + localStorage.getItem("id_agente"))
        .then(res => res.json())
        .then(res => {
            document.getElementById("Falhas").innerHTML += "<br><h3>Rejeitado: " + res + "</h3>";
        })

    fetch("http://localhost:8080/Transactions/countFraude/" + localStorage.getItem("id_agente"))
        .then(res => res.json())
        .then(res => {
            document.getElementById("Fraudes").innerHTML += "<br><h3>Fraude: " + res + "</h3>";
        })

    document.getElementById("Parceiro").innerHTML = localStorage.getItem("nome_agente");
    //document.getElementById("volume_transacional").innerHTML = localStorage.getItem("volume_tansacional");



    /*   fetch("http://localhost:8080/agentefinanceiros/" + document.getElementById("cmbartistas").value)
       .then(res => res.json())
       .then(res => {
           document.getElementById("dados").innerHTML = " <br><h3>Lançamento: " + res + "</h3>";
   
       })
   */
    /*
        fetch("http://localhost:8080/catalogo/" + document.getElementById("cmbartistas").value)
        .then(res => res.json())
        .then(res => {
            document.getElementById("dados").innerHTML+= " <br><h3>Catálogo: " + res + "</h3>";
        })
    */

}




function filtrar() {

    fetch("http://localhost:8080/agentefinanceiros")
        .then(res => res.json())
        .then(res => {

            localStorage.setItem("id_agente", document.getElementById("cmbartistas").value);
         

            //localStorage.setItem("id_agente", document.getElementById("mtb310_ag_financeiro").options[document.getElementById("mtb310_ag_financeiro").selectedIndex].value);
            localStorage.setItem("nome_agente", document.getElementById("cmbartistas").options[document.getElementById("cmbartistas").selectedIndex].text);
            localStorage.setItem("volume_transacional", document.getElementById("cmbartistas").options[document.getElementById("cmbartistas").selectedIndex].getAttribute("transacoes"));
            // var resposta =
            // "<table border='1' align='center' width=80% >" +
            // "<tr>"  +
            // "<th>Música</th> <th>Cadastro</th> <th>Lançamento</th>"
            // "</tr>";

            // for (contador=0; contador<res.musicas.length; contador++){
            //     lancamento="NÃO";
            //     if (res.musicas[contador].lancamento==1){
            //         lancamento="SIM";
            //     }

            //     resposta+=
            //     "<tr>" +
            //         "<td>" + res.musicas[contador].titulo + "</td>" +
            //         "<td>" + res.musicas[contador].cadastro + "</td>" +
            //         "<td>" + lancamento + "</td>" +
            //     "</tr>";
            // }


            // resposta+="</table>";
            // document.getElementById("tabelamusicas").innerHTML=resposta;
            window.location = "dashagfinanceiro.html";

        })
        .catch(err => {
            window.alert("Não tem Parceiro")
        });

}

function exibiragentefinanceiro() {
    fetch("http://localhost:8080/agentefinanceiros")
        .then(res => res.json())
        .then(res => {
            var resposta = "";
            for (contador = 0; contador < res.length; contador++) {
                resposta +=
                    "<option value='" + res[contador].id_agente + "'>" +
                    res[contador].nome_agente + "</option>";
            }
            document.getElementById("cmbartistas").innerHTML = resposta;
        })
        .catch(err => {
            window.alert("Sem agentes")
        });
}

function exibirlistatop10() {
    fetch("http://localhost:8080/agentefinanceirostop10")
        .then(res => res.json())
        .then(res => {
            var resposta =
                "<table border='1' align='center' width=80% >" +
                "<tr>" +
                "<th>Parceiro</th> <th>Volume Transacional</th>"
            "</tr>";

            for (contador = 0; contador < res.length; contador++) {
                resposta +=
                    "<tr>" +
                    "<td>" + res[contador].nome_agente + "</td>" +
                    "<td>" + res[contador].volume_transacional + "</td>" +
                    "</tr>";
            }

            //for
            resposta += "</table>";
            document.getElementById("top10").innerHTML = resposta;

        })
        .catch(err => {
            window.alert("Sem Top10")
        });

}

// Nova func
function exibirusuario() {

    exibiragentefinanceiro();
    exibirlistatop10();

    var userstr = localStorage.getItem("userlogado");
    if (userstr == null) {
        window.location = "login.html"
    } else {
        var userjson = JSON.parse(userstr);
        document.getElementById("dados").innerHTML =
            "<h6  align='left'>" + userjson.nome + "<br>" + userjson.email + "<br>ID: " + userjson.id + "</h6";

        document.getElementById("foto").innerHTML =
            "<img  alt= 'Imagem não carregada' width='5%' src=img/" + userjson.foto + ">";

    }
}
function exibirDeshAgFinaceiro() {


}
function Logout() {

    window.location = "login.html";

}

function logar() {

    var usuario = {
        email: document.getElementById("txtemail").value,
        senha: document.getElementById("txtsenha").value
    };

    var envelope = {
        method: "POST",
        body: JSON.stringify(usuario),
        headers: {
            "content-type": "application/json"
        }
    };

    fetch("http://localhost:8080/login", envelope)
        .then(res => res.json())
        .then(res => {
            localStorage.setItem("userlogado", JSON.stringify(res));
            window.location = "principal.html";
        })
        .catch(err => {
            window.alert("Usuário e/ou Senha inválido(s).");
        });
}





    //Alterações de hoje 21-05-2021


/*    function exibirdash() {

        fetch("http://localhost:8080/Transactions/countAceito/" + localStorage.getItem("id_selecionado"))
            .then(res => res.json())
            .then(res => {
                document.getElementById("dados").innerHTML = "<br><h3>Aceito: " + res + "</h3>";
            })

        fetch("http://localhost:8080/Transactions/countRejeitado/" + localStorage.getItem("id_selecionado"))
            .then(res => res.json())
            .then(res => {
                document.getElementById("dados").innerHTML += "<br><h3>Rejeitado: " + res + "</h3>";
            })

        fetch("http://localhost:8080/Transactions/countFraude/" + localStorage.getItem("id_selecionado"))
            .then(res => res.json())
            .then(res => {
                document.getElementById("dados").innerHTML += "<br><h3>Fraude: " + res + "</h3>";
            })

        document.getElementById("nome").innerHTML = localStorage.getItem("nome_selecionado");
        document.getElementById("qnt_transacoes").innerHTML = localStorage.getItem("qnt_transacoes");


    }
}
    */



/*
function filtrar() {
    localStorage.setItem("id_selecionado", document.getElementById("mtb310_ag_financeiro").options[document.getElementById("mtb310_ag_financeiro").selectedIndex].value);
    localStorage.setItem("nome_selecionado", document.getElementById("mtb310_ag_financeiro").options[document.getElementById("mtb310_ag_financeiro").selectedIndex].text);
    localStorage.setItem("qnt_transacoes", document.getElementById("mtb310_ag_financeiro").options[document.getElementById("mtb310_ag_financeiro").selectedIndex].getAttribute("transacoes"));
    window.location = "dashboard.html"
}
*/